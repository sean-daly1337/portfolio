package com.example.AssignmentTwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssignmentTwoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssignmentTwoApplication.class, args);
	}

}
